package net.minecraft.advancements.critereon;

import java.util.List;
import java.util.Optional;
import net.minecraft.core.HolderGetter;
import net.minecraft.util.ProblemReporter;
import net.minecraft.world.level.storage.loot.ValidationContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSet;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;

public class CriterionValidator {
    private final ProblemReporter reporter;
    private final HolderGetter.Provider lootData;

    public CriterionValidator(ProblemReporter reporter, HolderGetter.Provider lootData) {
        this.reporter = reporter;
        this.lootData = lootData;
    }

    public void validateEntity(Optional<ContextAwarePredicate> entity, String name) {
        entity.ifPresent(p_311858_ -> this.validateEntity(p_311858_, name));
    }

    public void validateEntities(List<ContextAwarePredicate> entities, String name) {
        this.validate(entities, LootContextParamSets.ADVANCEMENT_ENTITY, name);
    }

    public void validateEntity(ContextAwarePredicate entity, String name) {
        this.validate(entity, LootContextParamSets.ADVANCEMENT_ENTITY, name);
    }

    public void validate(ContextAwarePredicate p_312318_, LootContextParamSet p_312478_, String p_312401_) {
        p_312318_.validate(new ValidationContext(this.reporter.forChild(p_312401_), p_312478_, this.lootData));
    }

    public void validate(List<ContextAwarePredicate> p_312108_, LootContextParamSet p_312752_, String p_312670_) {
        for (int i = 0; i < p_312108_.size(); i++) {
            ContextAwarePredicate contextawarepredicate = p_312108_.get(i);
            contextawarepredicate.validate(new ValidationContext(this.reporter.forChild(p_312670_ + "[" + i + "]"), p_312752_, this.lootData));
        }
    }
}
