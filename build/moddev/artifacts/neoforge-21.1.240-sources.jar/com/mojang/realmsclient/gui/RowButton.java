package com.mojang.realmsclient.gui;

import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.realms.RealmsObjectSelectionList;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class RowButton {
    public final int width;
    public final int height;
    public final int xOffset;
    public final int yOffset;

    public RowButton(int width, int height, int xOffset, int yOffset) {
        this.width = width;
        this.height = height;
        this.xOffset = xOffset;
        this.yOffset = yOffset;
    }

    public void drawForRowAt(GuiGraphics guiGraphics, int x, int y, int mouseX, int mouseY) {
        int i = x + this.xOffset;
        int j = y + this.yOffset;
        boolean flag = mouseX >= i && mouseX <= i + this.width && mouseY >= j && mouseY <= j + this.height;
        this.draw(guiGraphics, i, j, flag);
    }

    protected abstract void draw(GuiGraphics guiGraphics, int x, int y, boolean showTooltip);

    public int getRight() {
        return this.xOffset + this.width;
    }

    public int getBottom() {
        return this.yOffset + this.height;
    }

    public abstract void onClick(int index);

    public static void drawButtonsInRow(
        GuiGraphics p_281401_, List<RowButton> p_283164_, RealmsObjectSelectionList<?> p_282348_, int p_282527_, int p_281326_, int p_281575_, int p_282538_
    ) {
        for (RowButton rowbutton : p_283164_) {
            if (p_282348_.getRowWidth() > rowbutton.getRight()) {
                rowbutton.drawForRowAt(p_281401_, p_282527_, p_281326_, p_281575_, p_282538_);
            }
        }
    }

    public static void rowButtonMouseClicked(
        RealmsObjectSelectionList<?> p_88037_, ObjectSelectionList.Entry<?> p_88038_, List<RowButton> p_88039_, int p_88040_, double p_88041_, double p_88042_
    ) {
        int i = p_88037_.children().indexOf(p_88038_);
        if (i > -1) {
            p_88037_.selectItem(i);
            int j = p_88037_.getRowLeft();
            int k = p_88037_.getRowTop(i);
            int l = (int)(p_88041_ - (double)j);
            int i1 = (int)(p_88042_ - (double)k);

            for (RowButton rowbutton : p_88039_) {
                if (l >= rowbutton.xOffset && l <= rowbutton.getRight() && i1 >= rowbutton.yOffset && i1 <= rowbutton.getBottom()) {
                    rowbutton.onClick(i);
                }
            }
        }
    }
}
